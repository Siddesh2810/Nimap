default_app_config = "apps.corecode.apps.CorecodeConfig"
